﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Products
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }

        public Products(int productID, string productName, string description, decimal price)
        {
            ProductID = productID;
            ProductName = productName;
            Description = description;
            Price = price;
        }

        public override string ToString()
        {
            return $"ProductID: {ProductID}, Name: {ProductName}, Description: {Description}, Price: {Price}";
        }
        // Get product details with exception handling
        public void GetProductDetails()
        {
            try
            {
                if (string.IsNullOrEmpty(ProductName))
                {
                    throw new InvalidDataException("Product name is not set.");
                }

                if (Price <= 0)
                {
                    throw new InvalidDataException("Product price must be greater than zero.");
                }

                Console.WriteLine($"ProductID: {ProductID}, Name: {ProductName}, Description: {Description}, Price: {Price:C}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"Error fetching product details: {ex.Message}");
            }
        }

        // Update product info with exception handling
        public void UpdateProductInfo(string description, decimal price)
        {
            try
            {
                if (string.IsNullOrEmpty(description))
                {
                    throw new InvalidDataException("Product description cannot be empty.");
                }

                if (price <= 0)
                {
                    throw new InvalidDataException("Product price must be greater than zero.");
                }

                Description = description;
                Price = price;
                Console.WriteLine("Product info updated successfully.");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"Error updating product info: {ex.Message}");
            }
        }

        // Check if product is in stock with exception handling
        public bool IsProductInStock(int quantityInStock)
        {
            try
            {
                if (quantityInStock < 0)
                {
                    throw new InsufficientStockException("Quantity in stock cannot be negative.");
                }

                return quantityInStock > 0;
            }
            catch (InsufficientStockException ex)
            {
                Console.WriteLine($"Error checking stock: {ex.Message}");
                return false;
            }
        }
    }
}
