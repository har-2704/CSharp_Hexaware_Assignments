﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //without db

            Customers customer1 = new Customers(1, "John", "Doe", "john.doe@example.com", "123-456-7890", "123 Elm St.");
            Console.WriteLine($"{customer1.FirstName}, {customer1.LastName}, {customer1.CustomerID}" );
            Products product1 = new Products(101, "Laptop", "High-performance laptop", 10500);
            Console.WriteLine($"{product1.ProductID}, {product1.ProductName}, {product1.Price} ");
            //Console.WriteLine($"Customer Name: {customer1.FirstName} {customer1.LastName}");
            //customer1.CalculateTotalOrders();
            //customer1.UpdateCustomerInfo(1, "priya_patel@mail.com", "8769587345", "Mumbai,Maharashtra");
            OrderDetail orderdetail1 = new OrderDetail(1, null, product1, 12);
            List<OrderDetail> orderdetail = new List<OrderDetail> { orderdetail1 };
            Orders order1 = new Orders(1, customer1.CustomerID, DateTime.Now, "Pending", 3000, orderdetail);
            orderdetail1.Order = order1;
            Console.WriteLine($"{orderdetail1.OrderDetailID}, {orderdetail1.Order}, {orderdetail1.Product}, {orderdetail1.Quantity}");
            
            //with db

            //CustomerCRUD

            //CustomersCRUD customersCRUD = new CustomersCRUD();
            //customersCRUD.GetCustomers();
            //customersCRUD.DeleteCustomer(10);
            //customersCRUD.AddCustomer("Kavya","Iyer","kavyaiyer@mail.com","9876543210","Chennai, TamilNadu");
            //customersCRUD.GetCustomers();
            //customersCRUD.UpdateCustomerEmail(2,"priyapatel@mail.com");

            //ProductCRUD

            //ProductsCRUD productsCRUD = new ProductsCRUD();
            //productsCRUD.AddProduct("Laptop", "HP Pavilion", 55000);
            //productsCRUD.GetProduct();
            //productsCRUD.UpdateProduct(4,"Laptop", "HP Pavilion Gaming", 60000);
            //productsCRUD.DeleteProduct(11);

            //OrderDetails

            //OrderDetailsCRUD orderdetailCRUD = new OrderDetailsCRUD();
            //orderdetailCRUD.GetOrderDetail(102);
            //orderdetailCRUD.AddOrderDetail(2, 4, 30);
            //orderdetailCRUD.UpdateOrderDetail(103, 2, 4, 20);
            //orderdetailCRUD.DeleteOrderDetail(103);
        }
    }
}
