﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class OrderDetail
    {
        public int OrderDetailID { get; set; }
        public Orders Order { get; set; }
        public Products Product { get; set; }
        public int Quantity { get; set; }

        public OrderDetail(int orderDetailID, Orders order, Products product, int quantity)
        {
            OrderDetailID = orderDetailID;
            Order = order;
            Product = product;
            Quantity = quantity;
        }

        public decimal CalculateSubtotal()
        {
            try
            {
                if (Product == null)
                    throw new InvalidDataException("Product is missing for this order detail.");

                return Product.Price * Quantity;
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return 0;
            }
        }
        public void GetOrderDetailInfo()
        {
            Console.WriteLine($"OrderDetailID: {OrderDetailID}, Product: {Product.ProductName}, Quantity: {Quantity}, Subtotal: {CalculateSubtotal():C}");
        }

        public void UpdateQuantity(int newQuantity)
        {
            Quantity = newQuantity;
            Console.WriteLine("Quantity updated successfully.");
        }

        public void AddDiscount(decimal discount)
        {
            decimal discounted = CalculateSubtotal() - discount;
            Console.WriteLine($"Discount: {discount:C}, New Subtotal: {discounted:C}");
        }
    }
}
