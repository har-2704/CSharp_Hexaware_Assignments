﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Orders
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }

        private List<OrderDetail> orderDetails;

        public Orders(int orderID, int customerID, DateTime orderDate, string status, decimal totalAmount, List<OrderDetail> orderDetails)
        {
            OrderID = orderID;
            CustomerID = customerID;
            OrderDate = orderDate;
            Status = status;
            TotalAmount = totalAmount;
            this.orderDetails = orderDetails;
        }

        public override string ToString()
        {
            return $"OrderID: {OrderID}, Date: {OrderDate.ToShortDateString()}, Status: {Status}";
        }
        public decimal CalculateTotalAmount()
        {
            try
            {
                if (orderDetails.Count == 0)
                    throw new Exception("No order details found to calculate total.");

                decimal total = 0;
                foreach (var detail in orderDetails)
                    total += detail.CalculateSubtotal();

                TotalAmount = total;
                return total;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error calculating total: {ex.Message}");
                return 0;
            }
        }

        public void GetOrderDetails()
        {
                Console.WriteLine($"OrderID: {OrderID}, Date: {OrderDate}, Status: {Status}");

                if (orderDetails.Count == 0)
                {
                    Console.WriteLine("No order details available.");
                }
                else
                {
                    foreach (var detail in orderDetails)
                        detail.GetOrderDetailInfo();
                }

                Console.WriteLine($"Total Amount: {TotalAmount:C}");
        }

        public void UpdateOrderStatus(string status)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(status))
                    throw new Exception("Status cannot be empty.");

                Status = status;
                Console.WriteLine($"Order status updated to: {Status}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating status: {ex.Message}");
            }
        }

        public void CancelOrder()
        {
            try
            {
                if (Status == "Cancelled")
                    throw new Exception($"Order {OrderID} is already cancelled.");

                Status = "Cancelled";
                Console.WriteLine($"Order {OrderID} has been cancelled.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error cancelling order: {ex.Message}");
            }
        }
    }
}