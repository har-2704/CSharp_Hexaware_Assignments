﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class OrderDetailsCRUD
    {
        string connectionString = "Server=DESKTOP-C2IRK4B\\SQLSERVER2022;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";
        string connectionString1 = "Data Source=DESKTOP-C2IRK4B\\SQLSERVER2022;Initial Catalog=Techshop;Integrated Security=True";
        public void AddOrderDetail(int orderId, int productId, int quantity)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO OrderDetails (OrderID, ProductID, Quantity) " +
                                   "VALUES (@OrderID, @ProductID, @Qty)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@OrderID", orderId);
                    cmd.Parameters.AddWithValue("@ProductID", productId);
                    cmd.Parameters.AddWithValue("@Qty", quantity);
                    
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Order detail added successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error adding order detail: " + ex.Message);
            }
        }

        // Read
        public void GetOrderDetail(int orderDetailId)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM OrderDetails WHERE OrderDetailID = @DetailID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@DetailID", orderDetailId);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        Console.WriteLine($"OrderDetailID: {reader["OrderDetailID"]}, OrderID: {reader["OrderID"]}, " +
                                          $"ProductID: {reader["ProductID"]}, Quantity: {reader["Quantity"]}");
                    }
                    else
                    {
                        Console.WriteLine("Order detail not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading order detail: " + ex.Message);
            }
        }

        // Update
        public void UpdateOrderDetail(int orderDetailId, int orderId, int productId, int quantity)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "UPDATE OrderDetails SET OrderID=@OrderID, ProductID=@ProductID, Quantity=@Qty WHERE OrderDetailID=@DetailID";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@DetailID", orderDetailId);
                    cmd.Parameters.AddWithValue("@OrderID", orderId);
                    cmd.Parameters.AddWithValue("@ProductID", productId);
                    cmd.Parameters.AddWithValue("@Qty", quantity);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                        Console.WriteLine("Order detail updated successfully.");
                    else
                        Console.WriteLine("Order detail not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating order detail: " + ex.Message);
            }
        }

        // Delete
        public void DeleteOrderDetail(int orderDetailId)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM OrderDetails WHERE OrderDetailID = @DetailID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@DetailID", orderDetailId);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                        Console.WriteLine("Order detail deleted successfully.");
                    else
                        Console.WriteLine("Order detail not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting order detail: " + ex.Message);
            }
        }
    }
}
