﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Inventory
    {
        public int InventoryID { get; set; }
        public Products Product { get; set; }
        public int QuantityInStock { get; set; }
        public DateTime LastStockUpdate { get; set; }
        public Inventory(int inventoryID, Products product, int quantityInStock)
        {
            InventoryID = inventoryID;
            Product = product;
            QuantityInStock = quantityInStock;
            LastStockUpdate = DateTime.Now;
        }
        public Products GetProduct()
        {
            return Product;
        }
        public int GetQuantityInStock()
        {
            return QuantityInStock;
        }
        public void AddToInventory(int quantity)
        {
            try
            {
                if (quantity < 0) throw new ArgumentException("Quantity must be positive.");
                QuantityInStock += quantity;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in AddToInventory: " + ex.Message);
            }
        }
        public void RemoveFromInventory(int quantity)
        {
            try
            {
                if (quantity < 0) throw new ArgumentException("Quantity must be positive.");
                if (QuantityInStock >= quantity)
                    QuantityInStock -= quantity;
                else
                    Console.WriteLine("Not enough stock to remove.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in RemoveFromInventory: " + ex.Message);
            }
        }
        public void UpdateStockQuantity(int newQuantity)
        {
            if (newQuantity < 0)
            {
                Console.WriteLine("Quantity cannot be negative.");
                return;
            }

            QuantityInStock = newQuantity;
            Console.WriteLine("Stock updated. New quantity: " + QuantityInStock);
        }
        public bool IsProductAvailable(int quantityToCheck)
        {
            return QuantityInStock >= quantityToCheck;
        }
        public decimal GetInventoryValue()
        {
            try
            {
                return Product.Price * QuantityInStock;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in GetInventoryValue: " + ex.Message);
                return 0;
            }
        }
        public void ListLowStockProducts(int threshold)
        {
            if (QuantityInStock < threshold)
                Console.WriteLine($"Low stock alert: {Product.ProductName} has only {QuantityInStock} left.");
            else
                Console.WriteLine($"{Product.ProductName} stock is sufficient: {QuantityInStock}");
        }
        public void ListOutOfStockProducts()
        {
            if (QuantityInStock == 0)
                Console.WriteLine($"{Product.ProductName} is out of stock.");
            else
                Console.WriteLine($"{Product.ProductName} is in stock: {QuantityInStock}");
        }
        public void ListAllProducts()
        {
            Console.WriteLine($"Product: {Product.ProductName}, Price: ₹{Product.Price}, Quantity: {QuantityInStock}");
        }
    }
}