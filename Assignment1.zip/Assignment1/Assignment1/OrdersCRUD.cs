﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class OrdersCRUD
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }

        private List<OrderDetail> orderDetails;

        string connectionString = "Server=DESKTOP-C2IRK4B\\SQLSERVER2022;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";
        string connectionString1 = "Data Source=DESKTOP-C2IRK4B\\SQLSERVER2022;Initial Catalog=Techshop;Integrated Security=True";
        public void CreateOrder()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Orders (OrderID, CustomerID, OrderDate, TotalAmount) VALUES (@OrderID, @CustomerID, @OrderDate, @TotalAmount)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@OrderID", OrderID);
                        cmd.Parameters.AddWithValue("@CustomerID", CustomerID); // Ensure 'Customer' is a valid value
                        cmd.Parameters.AddWithValue("@OrderDate", OrderDate);
                        //cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@TotalAmount", TotalAmount);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error inserting order: " + ex.Message);
            }
        }

        // READ
        public void ReadOrder(int id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Orders WHERE OrderID = @OrderID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@OrderID", id);
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        Console.WriteLine($"OrderID: {reader["OrderID"]}, CustomerID: {reader["CustomerID"]}, Date: {reader["OrderDate"]}, Status: {reader["Status"]}, Amount: {reader["TotalAmount"]}");
                    }
                    else
                    {
                        Console.WriteLine("Order not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading order: " + ex.Message);
            }
        }

        // UPDATE
        public void UpdateOrderStatus(int orderId, string newStatus)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Orders SET Status = @Status WHERE OrderID = @OrderID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Status", newStatus);
                    cmd.Parameters.AddWithValue("@OrderID", orderId);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    Console.WriteLine(rows > 0 ? "Order status updated successfully." : "Update failed.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating order status: " + ex.Message);
            }
        }

        // DELETE
        public void DeleteOrder(int id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Orders WHERE OrderID = @OrderID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@OrderID", id);
                    conn.Open();

                    int rows = cmd.ExecuteNonQuery();
                    Console.WriteLine(rows > 0 ? "Order deleted successfully." : "Delete failed.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting order: " + ex.Message);
            }
        }
    }
}