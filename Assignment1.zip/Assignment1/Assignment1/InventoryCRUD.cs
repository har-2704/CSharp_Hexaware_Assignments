﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class InventoryCRUD
    {
        public int InventoryID { get; set; }
        public Products Product { get; set; }
        public int QuantityInStock { get; set; }
        public DateTime LastStockUpdate { get; set; }

        string connectionString = "Server=DESKTOP-C2IRK4B\\SQLSERVER2022;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";
        string connectionString1 = "Data Source=DESKTOP-C2IRK4B\\SQLSERVER2022;Initial Catalog=Techshop;Integrated Security=True";
        public void InsertInventory()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Inventory (ProductID, QuantityInStock, LastStockUpdate) VALUES (@ProductID, @Quantity, @LastUpdate)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ProductID", Product.ProductID); 
                    cmd.Parameters.AddWithValue("@Quantity", QuantityInStock);
                    cmd.Parameters.AddWithValue("@LastUpdate", LastStockUpdate);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Inventory record inserted successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error inserting inventory: " + ex.Message);
            }
        }

        // READ
        public void GetInventory()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Inventory";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["InventoryID"]}, Product: {reader["ProductName"]}, Quantity: {reader["QuantityInStock"]}, Price: {reader["Price"]}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error retrieving inventory: " + ex.Message);
            }
        }

        // UPDATE
        public void UpdateInventory()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Inventory SET QuantityInStock = @Quantity WHERE InventoryID = @InventoryID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Quantity", QuantityInStock);
                    cmd.Parameters.AddWithValue("@InventoryID", InventoryID);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    Console.WriteLine(rows > 0 ? "Inventory updated successfully." : "Update failed.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating inventory: " + ex.Message);
            }
        }

        // DELETE
        public void DeleteInventory()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Inventory WHERE InventoryID = @InventoryID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@InventoryID", InventoryID);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    Console.WriteLine(rows > 0 ? "Inventory deleted successfully." : "Delete failed.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting inventory: " + ex.Message);
            }
        }
    }
}