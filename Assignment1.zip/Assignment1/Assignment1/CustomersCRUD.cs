﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class CustomersCRUD
    {
        string connectionString = "Server=DESKTOP-C2IRK4B\\SQLSERVER2022;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";
        string connectionString1 = "Data Source=DESKTOP-C2IRK4B\\SQLSERVER2022;Initial Catalog=Techshop;Integrated Security=True";
        public void AddCustomer(string FirstName,string LastName,string Email,string Phone ,string Address)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Customers (FirstName, LastName, Email, Phone ,Address) VALUES (@FName, @LName, @Email, @Ph, @Addr)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@FName", FirstName);
                    cmd.Parameters.AddWithValue("@LName", LastName);
                    cmd.Parameters.AddWithValue("@Email", Email);
                    cmd.Parameters.AddWithValue("@Ph", Phone);
                    cmd.Parameters.AddWithValue("@Addr", Address);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Customer inserted successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in AddCustomer: {ex.Message}");
            }
        }

        public void GetCustomers()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Customers";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    Console.WriteLine("Customers List:");
                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["CustomerID"]} - {reader["FirstName"]} {reader["LastName"]} , {reader["Email"]}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetCustomers: {ex.Message}");
            }
        }

        public void UpdateCustomerEmail(int id, string newEmail)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Customers SET Email = @Email WHERE CustomerID = @ID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Email", newEmail);
                    cmd.Parameters.AddWithValue("@ID", id);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                        Console.WriteLine("Customer email updated.");
                    else
                        Console.WriteLine("No customer found with that ID.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in UpdateCustomerEmail: {ex.Message}");
            }
        }

        public void DeleteCustomer(int id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Customers WHERE CustomerID = @ID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ID", id);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                        Console.WriteLine("Customer"+id+" deleted.");
                    else
                        Console.WriteLine("No customer found with that ID.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in DeleteCustomer: {ex.Message}");
            }
        }
    }
}
