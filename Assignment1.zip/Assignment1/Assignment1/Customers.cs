﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Customers
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }

        private List<Orders> orders;

        public Customers(int customerID, string firstName, string lastName, string email, string phone, string address)
        {
            CustomerID = customerID;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Phone = phone;
            Address = address;
            orders = new List<Orders>();
        }

        public void GetCustomerDetails()
        {
            try
            {
                // Checking if any essential customer info is missing
                if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(Email))
                {
                    throw new InvalidDataException("Customer details are incomplete.");
                }

                // Email format validation
                if (!Email.Contains("@"))
                {
                    throw new InvalidDataException("Invalid email address.");
                }

                Console.WriteLine($"CustomerID: {CustomerID}, Name: {FirstName} {LastName}, Email: {Email}, Phone: {Phone}, Address: {Address}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"Error fetching customer details: {ex.Message}");
            }
        }

        // Method to update customer info with exception handling
        public void UpdateCustomerInfo(int id,string email, string phone, string address)
        {
            try
            {
                // Validating email
                if (string.IsNullOrEmpty(email) || !email.Contains("@"))
                {
                    throw new InvalidDataException("Invalid email format.");
                }

                // Simple validation for other fields
                if (string.IsNullOrEmpty(phone))
                {
                    throw new InvalidDataException("Phone number cannot be empty.");
                }

                if (string.IsNullOrEmpty(address))
                {
                    throw new InvalidDataException("Address cannot be empty.");
                }
                if (this.CustomerID != id)
                {
                    Console.WriteLine("Customer ID does not match.");
                    return;
                }

                Email = email;
                Phone = phone;
                Address = address;

                Console.WriteLine("Customer info updated successfully.");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"Error updating customer info: {ex.Message}");
            }
        }

        // Method to calculate total number of orders placed by the customer
        public int CalculateTotalOrders()
        {
            try
            {
                if (orders == null || orders.Count == 0)
                {
                    throw new InvalidDataException("No orders placed by the customer.");
                }

                return orders.Count; // Return the number of orders
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"Error calculating total orders: {ex.Message}");
                return 0;  // Return 0 if there are no orders or an error occurs
            }

        }
    }
}

