﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class ProductsCRUD
    {
        string connectionString = "Server=DESKTOP-C2IRK4B\\SQLSERVER2022;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";
        string connectionString1 = "Data Source=DESKTOP-C2IRK4B\\SQLSERVER2022;Initial Catalog=Techshop;Integrated Security=True";
        public void AddProduct(string name, string description, decimal price)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Products (ProductName, Description, Price) VALUES (@Name, @Desc, @Price)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Desc", description);
                    cmd.Parameters.AddWithValue("@Price", price);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Product added successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error adding product: " + ex.Message);
            }
        }

        // Read
        public void GetProduct()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Products"; //WHERE ProductID = @Id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    //cmd.Parameters.AddWithValue("@Id", productId);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Console.WriteLine($"ProductID: {reader["ProductID"]}, Name: {reader["ProductName"]}, Description: {reader["Description"]}, Price: {reader["Price"]}");
                    }
                    //else
                    //{
                    //    Console.WriteLine("Product not found.");
                    //}
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading product: " + ex.Message);
            }
        }

        // Update
        public void UpdateProduct(int productId, string name, string description, decimal price)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Products SET ProductName=@Name, Description=@Desc, Price=@Price WHERE ProductID=@Id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Id", productId);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Desc", description);
                    cmd.Parameters.AddWithValue("@Price", price);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                        Console.WriteLine("Product updated successfully.");
                    else
                        Console.WriteLine("Product not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating product: " + ex.Message);
            }
        }

        // Delete
        public void DeleteProduct(int productId)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Products WHERE ProductID = @Id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Id", productId);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                        Console.WriteLine("Product deleted successfully.");
                    else
                        Console.WriteLine("Product not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting product: " + ex.Message);
            }
        }
    }
}
